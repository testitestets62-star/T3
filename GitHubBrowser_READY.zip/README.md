# GitHub Browser

A lightweight Android GitHub browser built with a native Android WebView.

## GitHub Actions

The repository builds the debug APK automatically on every push and can also be started manually with **Run workflow**.

The workflow intentionally uses Gradle 8.7 directly through `gradle/actions/setup-gradle`.
It does **not** require `gradlew` or `gradle-wrapper.properties`, so Java's Gradle cache setup cannot fail because a wrapper is missing.

## APK

After a successful Actions run, open the run and download the artifact:

`GitHubBrowser-debug-apk`
